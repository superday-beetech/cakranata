<script setup lang="ts">
defineProps<{
  open: boolean;
  items: Array<{ id: string; icon: string; label: string; shortcut?: string; disabled?: boolean }>;
}>();

const emit = defineEmits<{
  action: [id: string];
  toggle: [];
}>();
</script>

<template>
  <aside class="pos-dock" :class="{ 'is-collapsed': !open }" aria-label="Toolbar cepat">
    <button type="button" class="pos-dock-handle" :title="open ? 'Sembunyikan toolbar' : 'Tampilkan toolbar'" :aria-label="open ? 'Sembunyikan toolbar' : 'Tampilkan toolbar'" @click="emit('toggle')">
      <i :class="open ? 'ti ti-chevron-right' : 'ti ti-chevron-left'"></i>
    </button>

    <div v-show="open" class="pos-dock-items">
      <button
        v-for="item in items"
        :key="item.id"
        type="button"
        class="pos-dock-btn"
        :disabled="item.disabled"
        :title="item.shortcut ? `${item.label} (${item.shortcut})` : item.label"
        :aria-label="item.label"
        @click="emit('action', item.id)"
      >
        <i :class="item.icon"></i>
      </button>
    </div>
  </aside>
</template>
