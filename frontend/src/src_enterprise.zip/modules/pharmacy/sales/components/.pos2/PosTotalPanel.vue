<script setup lang="ts">
import { formatCurrency } from "../../utils/format";
defineProps<{
  total: number;
  paid: number;
  change: number;
  remaining: number;
  settlementLabel?: string;
}>();

</script>

<template>
  <section class="pos-total" aria-label="Total pembayaran">
    <div class="pos-total-top">
      <span>Total tagihan</span>
      <small>{{ settlementLabel || "Transaksi berjalan" }}</small>
    </div>

    <output class="pos-total-amount">{{ formatCurrency(total) }}</output>

    <div class="pos-total-stats">
      <div class="pos-total-stat">
        <small>Dibayar</small>
        <strong>{{ formatCurrency(paid) }}</strong>
      </div>

      <div class="pos-total-stat is-change">
        <small>Kembalian</small>
        <strong>{{ formatCurrency(change) }}</strong>
      </div>

      <div class="pos-total-stat is-remaining">
        <small>Sisa tagihan</small>
        <strong>{{ formatCurrency(remaining) }}</strong>
      </div>
    </div>
  </section>
</template>
