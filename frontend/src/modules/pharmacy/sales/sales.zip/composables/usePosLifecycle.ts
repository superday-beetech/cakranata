import { onMounted, onBeforeUnmount } from "vue";

interface UsePosLifecycleOptions {
  handleKeyboard: (event: KeyboardEvent) => void;
  handleDenominationShortcut: (event: KeyboardEvent) => void;
  loadHeldTransactions: () => Promise<unknown>;
  showError: (error: unknown) => void;
  focusBarcode: () => void;
  loadMenu: () => Promise<unknown>;
  loadPermission: () => Promise<unknown>;
  getOrganizationId: () => number | null;
  setInitialOrganizationId: (id: number | null) => void;
  syncOrganization: () => void;
}

export function usePosLifecycle(options: UsePosLifecycleOptions) {
  onMounted(async () => {
    window.addEventListener("keydown", options.handleKeyboard);
    window.addEventListener("keydown", options.handleDenominationShortcut);

    try {
      await options.loadHeldTransactions();
    } catch (error) {
      options.showError(error);
    }

    options.focusBarcode();

    void options.loadMenu().catch(() => undefined);
    void options.loadPermission().catch(() => undefined);

    options.setInitialOrganizationId(options.getOrganizationId());

    window.addEventListener("focus", options.syncOrganization);
  });

  onBeforeUnmount(() => {
    window.removeEventListener("keydown", options.handleKeyboard);
    window.removeEventListener("keydown", options.handleDenominationShortcut);
    window.removeEventListener("focus", options.syncOrganization);
  });
}
