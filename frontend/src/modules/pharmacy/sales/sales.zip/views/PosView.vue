<script setup lang="ts">
import "../styles/pos.css";
import { useAuthStore } from "@/stores/auth";
import { useRouter } from "vue-router";

const router = useRouter();
const { soundEnabled, play: playPosSound, toggle: togglePosSound } = usePosSound();

import { usePermissionStore } from "@/stores/permission";
import { useMenuStore } from "@/stores/menu";
import type { MenuItem } from "@/types/menu";
import { useOrganizationContextStore } from "@/modules/organization/stores/organizationContextStore";

import { computed, nextTick, defineAsyncComponent, onBeforeUnmount, onMounted, ref, watch, type ComponentPublicInstance } from "vue";
import type { PaymentMethod, ProductSearchResult, PosAdditionalCharge, Sale, SettlementMode, DiscountMode, TaxMode } from "../types/sales";
import productService from "../services/productService";
import CustomerAutocomplete from "@/modules/pharmacy/master/components/CustomerAutocomplete.vue";

import PosProductSearch from "../components/pos/PosProductSearch.vue";
import PosCart from "../components/pos/PosCart.vue";
import PosSummary from "../components/pos/PosSummary.vue";
import PosDiscountInput from "../components/pos/PosDiscountInput.vue";
import PosTaxInput from "../components/pos/PosTaxInput.vue";
import PosAdditionalCharges from "../components/pos/PosAdditionalCharges.vue";
import PosPayment from "../components/pos/PosPayment.vue";
import { POS_DENOMINATIONS } from "../utils/posDenominations";
import PosTotalPanel from "../components/pos/PosTotalPanel.vue";
import PosHeldTransactions from "../components/pos/PosHeldTransactions.vue";
import PosTransactionNotes from "../components/pos/PosTransactionNotes.vue";
import PosShortcutHelp from "../components/pos/PosShortcutHelp.vue";
import PosHeader from "../components/pos/PosHeader.vue";
import PosPanel from "../components/pos/PosPanel.vue";
import PosMenuBar from "../components/pos/PosMenuBar.vue";
import PosDock from "../components/pos/PosDock.vue";

import { usePosFeedback } from "../composables/usePosFeedback";
import { usePosDock, type DockEdge } from "../composables/usePosDock";
import { searchPosProducts, usePosProductSearch } from "../composables/usePosProductSearch";
import { usePosCartHandlers } from "../composables/usePosCartHandlers";
import { usePosTransactionAdjustments } from "../composables/usePosTransactionAdjustments";
import { usePosAdditionalCharges } from "../composables/usePosAdditionalCharges";
import { usePosPaymentHandlers } from "../composables/usePosPaymentHandlers";
import { usePosTransactionActions } from "../composables/usePosTransactionActions";
import { usePosKeyboard } from "../composables/usePosKeyboard";
import { usePosMenuActions } from "../composables/usePosMenuActions";
import { usePosDisplay } from "../composables/usePosDisplay";
import { usePosAdjustTabs, type AdjustTab } from "../composables/usePosAdjustTabs";
import { usePosFocus } from "../composables/usePosFocus";
import { usePosLifecycle } from "../composables/usePosLifecycle";

/** IMPORTIR */
import { usePosHost } from "../composables/usePosHost";
import { usePos } from "../composables/usePos";
import { usePosSound } from "../composables/usePosSound";
import { usePosDelight } from "../composables/usePosDelight";

defineOptions({
  name: "PosView",
});
const goToDashboard = () => {
  router.push("/pharmacy/sales/dashboard");
};

const {
  cart,
  keyword,
  searchResults,
  selectedCustomerId,
  paymentMethod,
  paymentAmount,
  notes,

  transactionDiscountMode,
  transactionDiscountValue,
  taxMode,
  taxValue,
  additionalCharges,
  settlementMode,
  dueDate,
  paymentReferenceNumber,

  subtotal,
  itemDiscount,
  transactionDiscount,
  discountTotal,
  dpp,
  taxAmount,
  additionalChargesTotal,
  grandTotal,

  appliedAmount,
  changeAmount,
  remainingAmount,

  loadingSearch,
  processing,
  currentSale,

  isDraft,
  isPosted,
  isCancelled,
  transactionLocked,
  canCreateDraft,
  canPostSale,

  searchProduct,
  clearSearch,
  addProduct,
  updateQuantity,
  updateUnitPrice,
  updateItemDiscount,
  updateItemNotes,
  removeProduct,
  clearCart,
  setCustomer,
  setPaymentAmount,
  setPaymentMethod,
  setTransactionDiscount,
  setTax,
  addAdditionalCharge,
  updateAdditionalCharge,
  removeAdditionalCharge,
  setSettlementMode,
  setDueDate,
  setPaymentReferenceNumber,
  payExact,
  resetPaymentAmount,
  //   payExactAmount,
  createDraft,
  postCurrentSale,
  newTransaction,

  heldTransactions,
  loadingHeldTransactions,
  loadHeldTransactions,
  holdCurrentSale,
  resumeHeldTransaction,
  paymentConfirmed,
  isPaymentValid,
  dueDateError,
  setPaymentConfirmed,
} = usePos({
  searchProducts: searchPosProducts,
});

const { message, errorMessage, clearMessages, showError, showSuccess } = usePosFeedback();
const { dock, toggleDock, moveDock, toggleDockVisibility } = usePosDock();

function onDockMove(payload: { edge: DockEdge; offset: number }): void {
  moveDock(payload.edge, payload.offset);
}

// Setelah satu aksi dipilih, toolbar terlipat lagi agar tidak menghalangi.
function onDockAction(id: string): void {
  runAction(id);
  dock.open = false;
}

/* Sentuhan visual (jam, sapaan, kedip keranjang). Harus setelah usePos karena membaca subtotal. */
const { clockTime, greeting, cartFlash } = usePosDelight(subtotal);
const { handleAddProduct, handleSearch, handleBarcodeEnter } = usePosProductSearch({
  keyword,

  getCart: () => cart.value,
  getSearchResults: () => searchResults.value,
  isTransactionLocked: () => transactionLocked.value,

  searchProduct,
  clearSearch,
  addProduct,

  clearMessages,
  showError,
  setErrorMessage: (text) => {
    errorMessage.value = text;
  },

  playSound: playPosSound,
  focusBarcode,
});

const saleStatus = computed(() => {
  if (isPosted.value) return "Selesai";
  if (isDraft.value) return "Draft";
  return "Baru";
});

const barcodeSection = ref<HTMLElement | ComponentPublicInstance | null>(null);
const customerSection = ref<HTMLElement | null>(null);
const cartSection = ref<HTMLElement | ComponentPublicInstance | null>(null);
const discountSection = ref<HTMLElement | null>(null);
const chargesSection = ref<HTMLElement | null>(null);
const paymentSection = ref<HTMLElement | ComponentPublicInstance | null>(null);
const paymentInput = ref<HTMLElement | null>(null);
function focusPaymentAmount(): void {
  focusPaymentAmountInternal(paymentInput.value);
}
const bankName = ref("");
const accountNumber = ref("");
const accountHolder = ref("");
const qrisImageUrl = ref<string | null>(null);
// const selectedPaymentMethod = computed<PaymentMethod>(() => paymentMethod.value ?? "cash");
const settlementLabel = computed(() => {
  switch (settlementMode.value) {
    case "partial":
      return "Tempo - Bayar Sebagian";
    case "receivable":
      return "Tempo - Seluruhnya Piutang";
    default:
      return "Lunas";
  }
});

function focusBarcode(): void {
  const input = elementOf(barcodeSection.value)?.querySelector<HTMLInputElement>("input");

  input?.focus();
  input?.select();
}

const { handleQuantityChange, handlePriceChange, handleDiscountModeChange, handleDiscountChange, handleItemNoteChange, handleRemoveProduct, handleClearCart } = usePosCartHandlers({
  getCart: () => cart.value,

  updateQuantity,
  updateUnitPrice,
  updateItemDiscount,
  updateItemNotes,
  removeProduct,
  clearCart,

  showError,
});

const { handleTransactionDiscountMode, handleTransactionDiscountValue, handleTaxMode, handleTaxValue } = usePosTransactionAdjustments({
  getTransactionDiscountMode: () => transactionDiscountMode.value,
  getTransactionDiscountValue: () => transactionDiscountValue.value,
  getTaxMode: () => taxMode.value,
  getTaxValue: () => taxValue.value,

  setTransactionDiscount,
  setTax,
});

const { addCharge, updateCharge, removeCharge } = usePosAdditionalCharges({
  addAdditionalCharge,
  updateAdditionalCharge,
  removeAdditionalCharge,
  showError,
});

const { handleSettlementMode, handlePaymentAmount, handlePaymentMethod, handleDueDate, handleReferenceNumber, handleExactPayment, handleResetPayment, handlePaymentConfirmation } = usePosPaymentHandlers({
  getSettlementMode: () => settlementMode.value,

  setSettlementMode,
  setPaymentAmount,
  setPaymentMethod,
  setDueDate,
  setPaymentReferenceNumber,
  payExact,
  resetPaymentAmount,
  setPaymentConfirmed,
});

/**
 * Diskon transaksi dan pajak sudah dipetakan ke payload backend.
 * Biaya tambahan dan settlement tempo belum didukung oleh API lama.
 */
const hasUnsupportedDraftValues = computed(() => {
  return additionalChargesTotal.value > 0;
});

const { handleCreateDraft, handlePostSale, handleHoldSale, handleResumeSale, handleNewTransaction, handleRefreshHeld } = usePosTransactionActions({
  hasUnsupportedDraftValues: () => hasUnsupportedDraftValues.value,

  canPostSale: () => canPostSale.value,
  isPaymentValid: () => isPaymentValid.value,
  isPosted: () => isPosted.value,

  createDraft,
  postCurrentSale,
  holdCurrentSale,
  resumeHeldTransaction,
  loadHeldTransactions,
  newTransaction,

  clearMessages,
  setErrorMessage: (message) => {
    errorMessage.value = message;
  },
  showSuccess,
  showError,

  playTransactionSound: () => {
    void playPosSound("transaction");
  },

  focusBarcode,
});

const { handleKeyboard, handleDenominationShortcut } = usePosKeyboard({
  hostIsOpen: () => host.isOpen(),

  isProcessing: () => processing.value,
  isPosted: () => isPosted.value,
  isDraft: () => isDraft.value,
  getSettlementMode: () => settlementMode.value,
  getPaymentMethod: () => paymentMethod.value,

  setShortcutHelp: (visible) => {
    shortcutHelp.value = visible;
  },

  focusBarcode,

  focusCustomer: () => {
    focusSection(customerSection.value);
  },

  focusCart: () => {
    focusSection(cartSection.value);
  },

  focusPayment: () => {
    focusSection(paymentSection.value);
  },

  focusPaymentAmount,

  openAdjustTab: async (tab) => {
    const sections = {
      discount: discountSection.value,
      charges: chargesSection.value,
      notes: null,
      held: null,
    };

    adjustTab.value = tab;

    await nextTick();

    if (sections[tab]) {
      focusSection(sections[tab]);
    }
  },

  handleResetPayment,
  handleExactPayment,
  handlePaymentAmount,

  handleHoldSale,
  handleNewTransaction,
  handlePostSale,
  handleCreateDraft,
});

const { isFullscreen, compactHeader, syncFullscreen, toggleFullscreen, toggleCompact } = usePosDisplay({
  notifyWarning: (message) => host.notify("warning", message),
});

const { runAction } = usePosMenuActions({
  isDraft: () => isDraft.value,
  isPosted: () => isPosted.value,

  handleNewTransaction,
  handleHoldSale,
  handlePostSale,
  handleCreateDraft,
  handleRefreshHeld,

  setAdjustTab: (tab) => {
    adjustTab.value = tab;
  },

  focusBarcode,

  focusCustomer: () => {
    focusSection(customerSection.value);
  },

  focusCart: () => {
    focusSection(cartSection.value);
  },

  openAdjustTab: async (tab) => {
    const section = tab === "discount" ? discountSection.value : chargesSection.value;

    await openAdjustTab(tab, section);
  },

  focusPaymentAmount,

  handleExactPayment,
  handleResetPayment,

  toggleSound: togglePosSound,
  toggleDock,
  toggleDockVisibility,
  moveDock,

  toggleShortcutHelp: () => {
    shortcutHelp.value = !shortcutHelp.value;
  },

  showAbout: () => {
    showSuccess("ACN Pharmacy · Point of Sale");
  },

  openPrinterSettings: () => {
    host.openOffCanvas(PosPrinterSettings, {
      title: "Printer & struk",
    });
  },

  openPosSettings: () => {
    host.openOffCanvas(PosGeneralSettings, {
      title: "Pengaturan POS",
    });
  },

  openPaymentSettings: () => {
    host.openModal(PosPaymentIntegration, {
      title: "Integrasi pembayaran",
      size: "lg",
    });
  },

  toggleFullscreen: () => {
    void toggleFullscreen();
  },

  toggleCompact,

  handleLogout: () => {
    void handleLogout();
  },

  openPage,
  openUrl,
});
/* function openAdjustTab(tab: "discount" | "charges", section: HTMLElement | null): Promise<void> {
  return openAdjustTabInternal(tab, section);
} */

const { elementOf, focusSection, focusPaymentAmount: focusPaymentAmountInternal } = usePosFocus();

async function openAdjustTab(tab: AdjustTab, section: HTMLElement | null): Promise<void> {
  adjustTab.value = tab;
  await nextTick();
  focusSection(section);
}
const {
  adjustTab,
  adjustTabItems,
  onTabKeydown,
  openAdjustTab: openAdjustTabInternal,
} = usePosAdjustTabs({
  focusSection,
});

/* <!-- ============================================================================================-->*/

const POS_PERMISSIONS: { settings?: string; paymentIntegration?: string } = {};
const orgContext = useOrganizationContextStore();

const workspaceLabel = computed(() => [orgContext.activeOrganization?.name, orgContext.activeUnit?.name].filter(Boolean).join(" · "));

const cashierTitle = computed(() => (orgContext.membershipRole ? `Peran: ${orgContext.membershipRole}` : "Kasir yang sedang aktif"));

// Konteks organisasi ada di sesi server (dipakai semua tab). Cek ulang saat tab POS kembali aktif.
let lastOrganizationId: number | null = null;

function flattenMenu(items: MenuItem[]): MenuItem[] {
  return items.flatMap((item) => {
    if (item.children?.length) return flattenMenu(item.children);
    if (!item.url || item.url === "#" || item.is_divider || !item.is_active) return [];

    return [item];
  });
}

function can(code?: string): boolean {
  return !code || permission.hasPermission(code);
}

// Ganti sumbernya (quick_links / apps / sidebar) sesuai isi menu Anda.
const pageMenuItems = computed(() => {
  const source = menuStore.menus.quick_links.length ? menuStore.menus.quick_links : menuStore.menus.apps;

  return flattenMenu(source)
    .filter((item) => !String(item.url).includes("/pharmacy/sales/pos"))
    .slice(0, 20)
    .map((item) => ({ id: `url:${item.url}`, label: item.title }));
});

function openUrl(url: string): void {
  const href = /^(https?:)?\/\//i.test(url) ? url : router.resolve(url.startsWith("/") ? url : `/${url}`).href;

  window.open(href, "_blank", "noopener");
}

// Halaman tujuan menu. newTab: true = buka di tab baru agar transaksi berjalan tidak hilang.
const pageLinks: Record<string, { to: string; newTab: boolean }> = {
  "page-dashboard": { to: "/pharmacy/sales/dashboard", newTab: false },
  "page-sales": { to: "/pharmacy/reports/sales", newTab: true },
};
function openPage(id: string): void {
  const link = pageLinks[id];
  if (!link) return;

  if (link.newTab) {
    window.open(router.resolve(link.to).href, "_blank", "noopener");
    return;
  }

  // Draft sudah tersimpan di server; keranjang yang belum disimpan akan hilang.
  const unsaved = cart.value.length > 0 && !isDraft.value && !isPosted.value;

  if (unsaved && !window.confirm("Keranjang belum disimpan dan akan hilang. Tetap keluar dari halaman kasir?")) {
    return;
  }

  void router.push(link.to);
}

const menus = computed(() => [
  {
    id: "sales",
    label: "Penjualan",
    items: [
      { id: "sound", label: "Suara", checked: soundEnabled.value },
      { separator: true },
      { id: "dock-visible", label: "Toolbar melayang", checked: dock.visible },
      { id: "dock-edge-right", label: "Posisi toolbar: kanan", checked: dock.edge === "right" },
      { id: "dock-edge-left", label: "Posisi toolbar: kiri", checked: dock.edge === "left" },
      { id: "dock-edge-top", label: "Posisi toolbar: atas", checked: dock.edge === "top" },
      { id: "dock-edge-bottom", label: "Posisi toolbar: bawah", checked: dock.edge === "bottom" },
    ],
  },
  {
    id: "pages",
    label: "Halaman",
    items: pageMenuItems.value.length ? pageMenuItems.value : [{ label: menuStore.loading ? "Memuat…" : "Tidak ada halaman", disabled: true }],
  },
  {
    id: "settings",
    label: "Pengaturan",
    items: [
      { id: "settings-printer", label: "Printer & struk" },
      { id: "settings-pos", label: "Pengaturan POS" },
      { id: "settings-payment", label: "Integrasi pembayaran" },
      //       { id: "settings-pos", label: "Pengaturan POS", disabled: !can(POS_PERMISSIONS.settings) },
      // { id: "settings-payment", label: "Integrasi pembayaran", disabled: !can(POS_PERMISSIONS.paymentIntegration) },
    ],
  },
  {
    id: "view",
    label: "Tampilan",
    items: [{ id: "sound", label: "Suara", checked: soundEnabled.value }],
  },
  {
    id: "account",
    label: "Akun",
    items: [{ label: `Kasir: ${cashierName.value || "-"}`, disabled: true }, { separator: true }, { id: "logout", label: "Keluar (logout)" }],
  },

  {
    id: "help",
    label: "Bantuan",
    items: [{ id: "shortcuts", label: "Daftar shortcut keyboard" }, { separator: true }, { id: "about", label: "Tentang" }],
  },
]);

const dockItems = computed(() => [
  { id: "search", icon: "ti ti-barcode", label: "Cari produk", shortcut: "F1" },
  { id: "customer", icon: "ti ti-user", label: "Pelanggan", shortcut: "F2" },
  { id: "discount", icon: "ti ti-discount-2", label: "Diskon", shortcut: "F4" },
  { id: "exact", icon: "ti ti-check", label: "Uang pas", shortcut: "F9", disabled: settlementMode.value !== "paid" },
  { id: "hold", icon: "ti ti-player-pause", label: "Tahan", shortcut: "F10", disabled: !isDraft.value },
  { id: "new", icon: "ti ti-plus", label: "Transaksi baru", shortcut: "F11" },
  { id: "process", icon: "ti ti-device-floppy", label: isDraft.value ? "Proses transaksi" : "Buat draft", shortcut: "F12", disabled: isPosted.value || processing.value },
  { id: "shortcuts", icon: "ti ti-keyboard", label: "Bantuan shortcut" },
]);

const host = usePosHost();
const auth = useAuthStore();
const permission = usePermissionStore();
const menuStore = useMenuStore();
// Urutan field ini tebakan; sesuaikan setelah melihat tipe AuthUser.
function textOf(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

// Hanya username/email yang dijamin tipe AuthUser; field lain tergantung respons /auth/me.
const cashierName = computed(() => {
  const user = auth.user;

  if (!user) return "";

  return textOf(user["full_name"]) || textOf(user["name"]) || textOf(user["display_name"]) || textOf(user["username"]) || textOf(user["email"]);
});
const PosPrinterSettings = defineAsyncComponent(() => import("../components/settings/PosPrinterSettings.vue"));
const PosGeneralSettings = defineAsyncComponent(() => import("../components/settings/PosGeneralSettings.vue"));
const PosPaymentIntegration = defineAsyncComponent(() => import("../components/settings/PosPaymentIntegration.vue"));

async function syncOrganization(): Promise<void> {
  try {
    await orgContext.fetchCurrentContext();

    const id = orgContext.activeOrganization?.id ?? null;

    if (lastOrganizationId !== null && id !== lastOrganizationId) {
      host.notify("warning", "Organisasi aktif berubah di tab lain. Muat ulang halaman kasir sebelum melanjutkan transaksi.");
    }

    lastOrganizationId = id;
  } catch {
    /* abaikan; jaringan bisa sedang putus */
  }
}

async function handleLogout(): Promise<void> {
  const unsaved = cart.value.length > 0 && !isDraft.value && !isPosted.value;

  if (unsaved && !window.confirm("Keranjang belum disimpan dan akan hilang. Tetap keluar?")) return;

  const success = await auth.logout();

  if (success) {
    menuStore.clear();
    await router.replace("/login");
  } else if (auth.error) {
    host.notify("error", auth.error);
  }
}
/* --------------------------------------------------------------------------
 * PRODUCT SEARCH
 * ----------------------------------------------------------------------- */

async function searchProducts(searchKeyword: string): Promise<ProductSearchResult[]> {
  const response = await productService.getAll({
    page: 1,
    per_page: 20,
    search: searchKeyword,
    is_active: 1,
  });

  if (response.data.error) {
    const apiMessage = response.data.message;

    throw new Error(Array.isArray(apiMessage) ? apiMessage.join(", ") : apiMessage || "Gagal mengambil data produk.");
  }

  const products = response.data.data?.items ?? [];

  return products.map((product) => ({
    id: product.id,
    sku: product.sku ?? "",
    barcode: product.barcode ?? null,
    name: product.name,
    unit_name: product.unit_name ?? undefined,
    selling_price: Number(product.selling_price),
    // available_stock: product.available_stock,
    is_active: Number(product.is_active) === 1,
  }));
}

/* --------------------------------------------------------------------------
 * POS COMPOSABLE
 * ----------------------------------------------------------------------- */

/* --------------------------------------------------------------------------
 * LOCAL UI STATE
 * ----------------------------------------------------------------------- */

const shortcutHelp = ref(false);

/* --------------------------------------------------------------------------
 * CUSTOMER
 * ----------------------------------------------------------------------- */

function handleCustomerChange(customerId: number | null): void {
  setCustomer(customerId);
}

/* --------------------------------------------------------------------------
 * TRANSACTION ACTIONS
 * ----------------------------------------------------------------------- */
usePosLifecycle({
  handleKeyboard,
  handleDenominationShortcut,
  loadHeldTransactions,
  showError,
  focusBarcode,
  loadMenu: () => menuStore.load(),
  loadPermission: () => permission.load(),
  getOrganizationId: () => orgContext.activeOrganization?.id ?? null,
  setInitialOrganizationId: (id) => {
    lastOrganizationId = id;
  },
  syncOrganization,
});
</script>

<template>
  <div class="pos-page">
    <div class="pos-page">
      <PosMenuBar :menus="menus" :clock="clockTime" :greeting="greeting" :cashier="cashierName" :workspace="workspaceLabel" :user-title="cashierTitle" :fullscreen="isFullscreen" :compact="compactHeader" @action="runAction" />

      <!-- HEADER -->
      <PosHeader
        v-if="!compactHeader"
        :sale-number="currentSale?.sale_number"
        :status="saleStatus"
        :processing="processing"
        :loading-held="loadingHeldTransactions"
        :can-hold="isDraft"
        :can-new="isPosted"
        :sound-enabled="soundEnabled"
        @back="goToDashboard"
        @new-transaction="handleNewTransaction"
        @hold-transaction="handleHoldSale"
        @refresh="handleRefreshHeld"
        @toggle-sound="togglePosSound"
        @toggle-shortcuts="shortcutHelp = !shortcutHelp"
      />

      <!-- BANTUAN SHORTCUT & NOTIFIKASI (melayang, tidak menggeser layout) -->
      <PosShortcutHelp :visible="shortcutHelp" @close="shortcutHelp = false" />

      <div v-if="message || errorMessage" class="pos-toasts">
        <div v-if="message" class="alert alert-success" role="status">
          <i class="ti ti-circle-check fs-5"></i>
          <span>{{ message }}</span>
          <button type="button" class="btn btn-icon btn-sm btn-soft-success" aria-label="Tutup pesan" @click="message = ''">
            <i class="ti ti-x"></i>
          </button>
        </div>

        <div v-if="errorMessage" class="alert alert-danger" role="alert">
          <i class="ti ti-alert-circle fs-5"></i>
          <span>{{ errorMessage }}</span>
          <button type="button" class="btn btn-icon btn-sm btn-soft-danger" aria-label="Tutup pesan" @click="errorMessage = ''">
            <i class="ti ti-x"></i>
          </button>
        </div>
      </div>

      <main class="pos-main">
        <!-- KIRI: INPUT & KERANJANG -->
        <section class="pos-left">
          <div v-if="isPosted" class="card pos-posted">
            <i class="ti ti-circle-check text-success"></i>

            <div>
              <strong>Transaksi berhasil diselesaikan</strong>
              <small>{{ currentSale?.sale_number }}</small>
            </div>

            <button type="button" class="btn btn-primary btn-sm" @click="handleNewTransaction">
              <i class="ti ti-plus"></i>
              Transaksi baru
            </button>
          </div>

          <div class="pos-entry">
            <PosProductSearch
              ref="barcodeSection"
              v-model:keyword="keyword"
              :results="searchResults"
              :loading="loadingSearch"
              :disabled="transactionLocked || processing"
              @search="handleSearch"
              @enter="handleBarcodeEnter"
              @select="handleAddProduct"
            />

            <div ref="customerSection" class="card pos-customer">
              <label class="pos-field-label">
                <i class="ti ti-user"></i>
                Pelanggan
                <kbd>F2</kbd>
              </label>

              <CustomerAutocomplete :model-value="selectedCustomerId" :disabled="transactionLocked || processing" @update:model-value="handleCustomerChange" />
            </div>
          </div>

          <PosCart
            ref="cartSection"
            class="pos-cart"
            :class="{ 'is-flash': cartFlash }"
            :items="cart"
            :subtotal="subtotal"
            :disabled="transactionLocked || processing"
            shortcut="F3"
            @quantity-change="handleQuantityChange"
            @price-change="handlePriceChange"
            @discount-mode-change="handleDiscountModeChange"
            @discount-change="handleDiscountChange"
            @note-change="handleItemNoteChange"
            @remove="handleRemoveProduct"
            @clear="handleClearCart"
          />
        </section>

        <!-- TENGAH: PENYESUAIAN & RINGKASAN -->
        <section class="pos-middle">
          <!-- PENYESUAIAN TRANSAKSI (tab agar hemat ruang) -->
          <section class="card pos-adjust">
            <div class="pos-tabs" role="tablist" aria-label="Penyesuaian transaksi">
              <button
                v-for="(tab, index) in adjustTabItems"
                :id="`pos-tab-${tab.id}`"
                :key="tab.id"
                type="button"
                class="pos-tab"
                :class="{ 'is-active': adjustTab === tab.id }"
                role="tab"
                :aria-selected="adjustTab === tab.id"
                :aria-controls="`pos-tabpanel-${tab.id}`"
                :aria-label="tab.fullLabel"
                :title="tab.fullLabel"
                :tabindex="adjustTab === tab.id ? 0 : -1"
                @click="adjustTab = tab.id"
                @keydown="onTabKeydown($event, index)"
              >
                <i :class="tab.icon"></i>
                <span class="pos-tab-label">{{ tab.label }}</span>
                <span v-if="tab.id === 'charges' && additionalCharges.length" class="pos-tab-badge">{{ additionalCharges.length }}</span>
                <span v-else-if="tab.id === 'notes' && notes" class="pos-tab-badge">1</span>
                <span v-else-if="tab.id === 'held' && heldTransactions.length" class="pos-tab-badge">{{ heldTransactions.length }}</span>
                <kbd v-if="tab.shortcut">{{ tab.shortcut }}</kbd>
              </button>
            </div>

            <div class="pos-adjust-body">
              <div v-show="adjustTab === 'discount'" id="pos-tabpanel-discount" ref="discountSection" role="tabpanel" aria-labelledby="pos-tab-discount">
                <PosDiscountInput
                  :mode="transactionDiscountMode"
                  :value="transactionDiscountValue"
                  :base-amount="Math.max(0, subtotal - itemDiscount)"
                  :disabled="transactionLocked || processing"
                  @update:mode="handleTransactionDiscountMode"
                  @update:value="handleTransactionDiscountValue"
                />
              </div>

              <div v-show="adjustTab === 'charges'" id="pos-tabpanel-charges" ref="chargesSection" role="tabpanel" aria-labelledby="pos-tab-charges">
                <PosAdditionalCharges :charges="additionalCharges" :disabled="transactionLocked || processing" @add="addCharge" @update="updateCharge" @remove="removeCharge" />
              </div>

              <div v-show="adjustTab === 'notes'" id="pos-tabpanel-notes" class="h-100" role="tabpanel" aria-labelledby="pos-tab-notes">
                <PosTransactionNotes v-model="notes" :disabled="transactionLocked || processing" />
              </div>

              <div v-show="adjustTab === 'held'" id="pos-tabpanel-held" role="tabpanel" aria-labelledby="pos-tab-held">
                <PosHeldTransactions :transactions="heldTransactions" :loading="loadingHeldTransactions" :disabled="processing" @refresh="handleRefreshHeld" @resume="handleResumeSale" />
              </div>
            </div>
          </section>

          <PosPanel title="Ringkasan" icon="ti ti-receipt" tone="success">
            <PosSummary :subtotal="subtotal" :item-discount="itemDiscount" :transaction-discount="transactionDiscount" :dpp="dpp" :tax="taxAmount" :additional-charges="additionalChargesTotal" :total="grandTotal" :show-total="false" />

            <div class="pos-tax-row">
              <label><i class="ti ti-percentage"></i>Atur pajak</label>

              <PosTaxInput :mode="taxMode" :value="taxValue" :base-amount="dpp" :disabled="transactionLocked || processing" :show-preview="false" @update:mode="handleTaxMode" @update:value="handleTaxValue" />
            </div>
          </PosPanel>
        </section>

        <!-- KANAN: PEMBAYARAN & AKSI -->
        <aside class="pos-right">
          <div class="pos-right-scroll">
            <PosPanel ref="paymentSection" title="Pembayaran" icon="ti ti-wallet" tone="primary" shortcut="F6">
              <div ref="paymentInput">
                <PosPayment
                  :mode="settlementMode"
                  :payment-method="paymentMethod"
                  :payment-amount="paymentAmount"
                  :total="grandTotal"
                  :due-date="dueDate"
                  :due-date-error="dueDateError"
                  :reference-number="paymentReferenceNumber"
                  :payment-confirmed="paymentConfirmed"
                  :disabled="processing || isPosted"
                  :bank-name="bankName"
                  :account-number="accountNumber"
                  :account-holder="accountHolder"
                  :qris-image-url="qrisImageUrl"
                  @update:mode="handleSettlementMode"
                  @update:payment-method="handlePaymentMethod"
                  @update:payment-amount="handlePaymentAmount"
                  @update:due-date="handleDueDate"
                  @update:reference-number="handleReferenceNumber"
                  @update:payment-confirmed="handlePaymentConfirmation"
                  @exact="handleExactPayment"
                  @reset="handleResetPayment"
                />
              </div>
            </PosPanel>
          </div>

          <!-- TOTAL & AKSI: selalu terlihat di bawah -->
          <section class="card pos-final">
            <PosTotalPanel :total="grandTotal" :paid="appliedAmount" :change="changeAmount" :remaining="remainingAmount" :settlement-label="settlementLabel" />

            <div class="pos-final-actions">
              <button v-if="!isDraft && !isPosted" type="button" class="btn btn-primary btn-lg" :disabled="!canCreateDraft || processing" @click="handleCreateDraft">
                <span v-if="processing" class="spinner-border spinner-border-sm" aria-hidden="true"></span>
                <i v-else class="ti ti-device-floppy"></i>
                Buat draft penjualan
                <kbd>F12</kbd>
              </button>

              <button v-else-if="isDraft" type="button" class="btn btn-success btn-lg" :disabled="!canPostSale || !isPaymentValid || processing" @click="handlePostSale">
                <span v-if="processing" class="spinner-border spinner-border-sm" aria-hidden="true"></span>
                <i v-else class="ti ti-check"></i>
                Posting penjualan
                <kbd>F12</kbd>
              </button>

              <button v-else type="button" class="btn btn-primary btn-lg" :disabled="processing" @click="handleNewTransaction">
                <i class="ti ti-plus"></i>
                Transaksi baru
                <kbd>F11</kbd>
              </button>

              <small v-if="isDraft">
                <i class="ti ti-info-circle"></i>
                Draft tersimpan. Periksa transaksi sebelum posting.
              </small>
            </div>
          </section>
        </aside>
      </main>
      <PosDock v-if="dock.visible" :open="dock.open" :edge="dock.edge" :offset="dock.offset" :items="dockItems" @action="onDockAction" @toggle="toggleDock" @move="onDockMove" />
    </div>
  </div>
</template>
