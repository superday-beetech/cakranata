<?php

declare(strict_types=1);

namespace Modules\Pharmacy\Services;

use Config\Database;
use DateTimeImmutable;
use RuntimeException;
use Throwable;

class DistributionService
{
    protected $db;

    public function __construct()
    {
        $this->db = Database::connect('pharmacy');
    }

    /**
     * Membuat pesanan distribusi.
     *
     * Format:
     * [
     *   'order_number' => 'DO-001',
     *   'customer_id' => 1,
     *   'order_date' => '2026-11-05',
     *   'requested_delivery_date' => '2026-11-06',
     *   'items' => [
     *      [
     *          'product_id' => 1,
     *          'quantity' => 10,
     *          'unit_price' => 50000,
     *          'discount_amount' => 0,
     *      ],
     *   ],
     * ]
     */
    public function createDistributionOrder(
        array $data,
        int $userId
    ): int {
        $this->validateOrderData($data);

        $this->db->transBegin();

        try {
            $customer = $this->db->table('customers')
                ->where('id', (int) $data['customer_id'])
                ->where('is_active', 1)
                ->get()
                ->getRowArray();

            if (!$customer) {
                throw new RuntimeException('Pelanggan tidak ditemukan atau tidak aktif.');
            }

            $subtotal = 0.0;
            $discountTotal = 0.0;
            $items = [];

            foreach ($data['items'] as $item) {
                $product = $this->db->table('products')
                    ->where('id', (int) $item['product_id'])
                    ->where('is_active', 1)
                    ->get()
                    ->getRowArray();

                if (!$product) {
                    throw new RuntimeException(
                        'Produk ID ' . $item['product_id'] . ' tidak ditemukan atau tidak aktif.'
                    );
                }

                $quantity = (float) $item['quantity'];
                $unitPrice = (float) $item['unit_price'];
                $discount = (float) ($item['discount_amount'] ?? 0);

                $lineSubtotal = ($quantity * $unitPrice) - $discount;

                if ($lineSubtotal < 0) {
                    throw new RuntimeException('Diskon item tidak boleh melebihi nilai item.');
                }

                $subtotal += $quantity * $unitPrice;
                $discountTotal += $discount;

                $items[] = [
                    'product_id' => (int) $item['product_id'],
                    'quantity' => $quantity,
                    'unit_price' => $unitPrice,
                    'discount_amount' => $discount,
                    'subtotal' => $lineSubtotal,
                    'notes' => $item['notes'] ?? null,
                ];
            }

            $headerDiscount = (float) ($data['discount_amount'] ?? 0);
            $taxAmount = (float) ($data['tax_amount'] ?? 0);

            if ($headerDiscount < 0 || $taxAmount < 0) {
                throw new RuntimeException('Diskon dan pajak tidak boleh bernilai negatif.');
            }

            $totalDiscount = $discountTotal + $headerDiscount;
            $totalAmount = $subtotal - $totalDiscount + $taxAmount;

            if ($totalAmount < 0) {
                throw new RuntimeException('Total pesanan tidak valid.');
            }

            $this->db->table('distribution_orders')->insert([
                'order_number' => $data['order_number'],
                'customer_id' => (int) $data['customer_id'],
                'order_date' => $data['order_date'],
                'requested_delivery_date' => $data['requested_delivery_date'] ?? null,
                'status' => 'draft',
                'subtotal' => $subtotal,
                'discount_amount' => $totalDiscount,
                'tax_amount' => $taxAmount,
                'total_amount' => $totalAmount,
                'notes' => $data['notes'] ?? null,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            $orderId = (int) $this->db->insertID();

            foreach ($items as $item) {
                $item['distribution_order_id'] = $orderId;

                $this->db->table('distribution_items')->insert($item);
            }

            $this->completeTransaction();

            return $orderId;
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }

    /**
     * Membuat dokumen pengiriman draft.
     */
    public function createDelivery(
        array $data,
        int $userId
    ): int {
        if (empty($data['delivery_number']) || empty($data['distribution_order_id'])) {
            throw new RuntimeException('Nomor pengiriman dan pesanan wajib diisi.');
        }

        $this->db->transBegin();

        try {
            $order = $this->db->query(
                'SELECT * FROM distribution_orders WHERE id = ? FOR UPDATE',
                [(int) $data['distribution_order_id']]
            )->getRowArray();

            if (!$order) {
                throw new RuntimeException('Pesanan distribusi tidak ditemukan.');
            }

            if (in_array($order['status'], ['cancelled', 'completed'], true)) {
                throw new RuntimeException('Pesanan tidak dapat dibuatkan pengiriman.');
            }

            $this->db->table('deliveries')->insert([
                'delivery_number' => $data['delivery_number'],
                'distribution_order_id' => (int) $data['distribution_order_id'],
                'delivery_date' => $data['delivery_date'],
                'status' => 'draft',
                'recipient_name' => $data['recipient_name'] ?? null,
                'recipient_phone' => $data['recipient_phone'] ?? null,
                'shipping_address' => $data['shipping_address'] ?? null,
                'notes' => $data['notes'] ?? null,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            $deliveryId = (int) $this->db->insertID();

            $this->completeTransaction();

            return $deliveryId;
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }

    /**
     * Posting pengiriman.
     *
     * $allocations bersifat opsional.
     *
     * Jika kosong, sistem mengalokasikan batch secara FEFO.
     *
     * Format alokasi manual:
     * [
     *   distribution_item_id => [
     *      ['batch_id' => 1, 'quantity' => 5],
     *      ['batch_id' => 2, 'quantity' => 3],
     *   ],
     * ]
     */
    public function postDelivery(
        int $deliveryId,
        int $userId,
        array $allocations = []
    ): array {
        $this->db->transBegin();

        try {
            $delivery = $this->db->query(
                'SELECT * FROM deliveries WHERE id = ? FOR UPDATE',
                [$deliveryId]
            )->getRowArray();

            if (!$delivery) {
                throw new RuntimeException('Dokumen pengiriman tidak ditemukan.');
            }

            if ($delivery['status'] !== 'draft') {
                throw new RuntimeException('Pengiriman sudah diproses atau bukan berstatus draft.');
            }

            $orderId = (int) $delivery['distribution_order_id'];

            $order = $this->db->query(
                'SELECT * FROM distribution_orders WHERE id = ? FOR UPDATE',
                [$orderId]
            )->getRowArray();

            if (!$order) {
                throw new RuntimeException('Pesanan distribusi tidak ditemukan.');
            }

            if (in_array($order['status'], ['cancelled', 'completed'], true)) {
                throw new RuntimeException('Pesanan tidak dapat diproses.');
            }

            $orderItems = $this->db->query(
                'SELECT * FROM distribution_items
                 WHERE distribution_order_id = ?
                 ORDER BY id ASC
                 FOR UPDATE',
                [$orderId]
            )->getResultArray();

            if (!$orderItems) {
                throw new RuntimeException('Detail pesanan tidak ditemukan.');
            }

            $postedItems = 0;
            $totalDispatched = 0.0;

            foreach ($orderItems as $orderItem) {
                $itemId = (int) $orderItem['id'];
                $productId = (int) $orderItem['product_id'];

                // Total pengiriman yang sudah diposting untuk item ini.
                $deliveredRow = $this->db->query(
                    'SELECT COALESCE(SUM(di.quantity_dispatched), 0) AS total
                     FROM delivery_items di
                     INNER JOIN deliveries d ON d.id = di.delivery_id
                     WHERE di.distribution_item_id = ?
                       AND d.status = ?',
                    [$itemId, 'posted']
                )->getRowArray();

                $alreadyDelivered = (float) ($deliveredRow['total'] ?? 0);
                $orderedQuantity = (float) $orderItem['quantity'];
                $remainingOrder = $orderedQuantity - $alreadyDelivered;

                if ($remainingOrder <= 0) {
                    continue;
                }

                $requestedAllocations = $allocations[$itemId] ?? null;

                if ($requestedAllocations === null) {
                    $requestedAllocations = $this->allocateFefo(
                        $productId,
                        $remainingOrder
                    );
                }

                if (!$requestedAllocations) {
                    continue;
                }

                $allocationTotal = 0.0;

                foreach ($requestedAllocations as $allocation) {
                    $batchId = (int) ($allocation['batch_id'] ?? 0);
                    $quantity = (float) ($allocation['quantity'] ?? 0);

                    if ($batchId <= 0 || $quantity <= 0) {
                        throw new RuntimeException('Data alokasi batch tidak valid.');
                    }

                    $allocationTotal += $quantity;
                }

                if ($allocationTotal > $remainingOrder + 0.0001) {
                    throw new RuntimeException(
                        'Jumlah pengiriman melebihi sisa pesanan item ID ' . $itemId
                    );
                }

                foreach ($requestedAllocations as $allocation) {
                    $batchId = (int) $allocation['batch_id'];
                    $quantity = (float) $allocation['quantity'];

                    // Kunci batch untuk mencegah dua transaksi mengambil stok yang sama.
                    $batch = $this->db->query(
                        'SELECT * FROM product_batches
                         WHERE id = ?
                           AND product_id = ?
                         FOR UPDATE',
                        [$batchId, $productId]
                    )->getRowArray();

                    if (!$batch) {
                        throw new RuntimeException(
                            'Batch ID ' . $batchId . ' tidak ditemukan untuk produk ini.'
                        );
                    }

                    if ($batch['status'] !== 'available') {
                        throw new RuntimeException('Batch tidak tersedia untuk dikirim.');
                    }

                    if (
                        !empty($batch['expired_at'])
                        && $batch['expired_at'] < date('Y-m-d')
                    ) {
                        throw new RuntimeException('Batch sudah melewati tanggal kedaluwarsa.');
                    }

                    if ((float) $batch['quantity_remaining'] < $quantity) {
                        throw new RuntimeException(
                            'Stok batch tidak mencukupi. Batch ID: ' . $batchId
                        );
                    }

                    // Kurangi stok dengan kondisi saldo agar tetap aman.
                    $this->db->table('product_batches')
                        ->where('id', $batchId)
                        ->where('quantity_remaining >=', $quantity)
                        ->update([
                            'quantity_remaining' =>
                            (float) $batch['quantity_remaining'] - $quantity,
                        ]);

                    if ($this->db->affectedRows() !== 1) {
                        throw new RuntimeException('Gagal memperbarui saldo batch.');
                    }

                    $unitPrice = (float) $orderItem['unit_price'];

                    $this->db->table('delivery_items')->insert([
                        'delivery_id' => $deliveryId,
                        'distribution_item_id' => $itemId,
                        'batch_id' => $batchId,
                        'quantity_dispatched' => $quantity,
                        'unit_price' => $unitPrice,
                    ]);

                    $this->db->table('stock_movements')->insert([
                        'product_id' => $productId,
                        'batch_id' => $batchId,
                        'movement_date' => $delivery['delivery_date'],
                        'movement_type' => 'out',
                        'reference_type' => 'delivery',
                        'reference_id' => $deliveryId,
                        'quantity_in' => 0,
                        'quantity_out' => $quantity,
                        'unit_cost' => $batch['unit_cost'],
                        'notes' => 'Delivery ' . $delivery['delivery_number'],
                        'created_by' => $userId,
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);

                    $postedItems++;
                    $totalDispatched += $quantity;
                }
            }

            if ($postedItems === 0) {
                throw new RuntimeException('Tidak ada barang yang dapat dikirim.');
            }

            $this->db->table('deliveries')
                ->where('id', $deliveryId)
                ->update([
                    'status' => 'posted',
                    'updated_by' => $userId,
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);

            // Perbarui status pesanan berdasarkan total kuantitas terkirim.
            $status = $this->resolveOrderStatus($orderId);

            $this->db->table('distribution_orders')
                ->where('id', $orderId)
                ->update([
                    'status' => $status,
                    'updated_by' => $userId,
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);

            $this->completeTransaction();

            return [
                'delivery_id' => $deliveryId,
                'status' => 'posted',
                'order_status' => $status,
                'total_dispatched' => $totalDispatched,
            ];
        } catch (Throwable $e) {
            $this->db->transRollback();
            throw $e;
        }
    }

    /**
     * Alokasi batch FEFO.
     *
     * Dipanggil saat posting, bukan sebagai reservasi stok.
     * Batch akan dikunci dan divalidasi ulang saat proses posting.
     */
    private function allocateFefo(
        int $productId,
        float $quantity
    ): array {
        $batches = $this->db->query(
            'SELECT * FROM product_batches
             WHERE product_id = ?
               AND status = ?
               AND quantity_remaining > 0
               AND (expired_at IS NULL OR expired_at >= ?)
             ORDER BY expired_at IS NULL ASC, expired_at ASC, id ASC',
            [$productId, 'available', date('Y-m-d')]
        )->getResultArray();

        $remaining = $quantity;
        $allocations = [];

        foreach ($batches as $batch) {
            if ($remaining <= 0) {
                break;
            }

            $available = (float) $batch['quantity_remaining'];
            $take = min($available, $remaining);

            if ($take <= 0) {
                continue;
            }

            $allocations[] = [
                'batch_id' => (int) $batch['id'],
                'quantity' => $take,
            ];

            $remaining -= $take;
        }

        if ($remaining > 0.0001) {
            throw new RuntimeException(
                'Stok tidak mencukupi untuk produk ID ' . $productId
            );
        }

        return $allocations;
    }


    private function resolveOrderStatus(int $orderId): string
    {
        $result = $this->db->query(
            'SELECT
            (
                SELECT COALESCE(SUM(quantity), 0)
                FROM distribution_items
                WHERE distribution_order_id = ?
            ) AS ordered_quantity,
            (
                SELECT COALESCE(SUM(di.quantity_dispatched), 0)
                FROM delivery_items di
                INNER JOIN deliveries d ON d.id = di.delivery_id
                INNER JOIN distribution_items oi
                    ON oi.id = di.distribution_item_id
                WHERE oi.distribution_order_id = ?
                  AND d.status = ?
            ) AS delivered_quantity',
            [$orderId, $orderId, 'posted']
        )->getRowArray();

        $ordered = (float) ($result['ordered_quantity'] ?? 0);
        $delivered = (float) ($result['delivered_quantity'] ?? 0);

        if ($delivered >= $ordered - 0.0001) {
            return 'completed';
        }

        if ($delivered > 0) {
            return 'partially_delivered';
        }

        return 'draft';
    }


    /* private function resolveOrderStatus(int $orderId): string
    {
        $result = $this->db->query(
            'SELECT
                SUM(di.quantity) AS ordered_quantity,
                COALESCE(SUM(
                    CASE WHEN d.status = ?
                    THEN dei.quantity_dispatched ELSE 0 END
                ), 0) AS delivered_quantity
             FROM distribution_items di
             LEFT JOIN delivery_items dei
                ON dei.distribution_item_id = di.id
             LEFT JOIN deliveries d
                ON d.id = dei.delivery_id
             WHERE di.distribution_order_id = ?',
            ['posted', $orderId]
        )->getRowArray();

        $ordered = (float) ($result['ordered_quantity'] ?? 0);
        $delivered = (float) ($result['delivered_quantity'] ?? 0);

        if ($delivered >= $ordered - 0.0001) {
            return 'completed';
        }

        if ($delivered > 0) {
            return 'partially_delivered';
        }

        return 'draft';
    } */

    private function validateOrderData(array $data): void
    {
        foreach (['order_number', 'customer_id', 'order_date', 'items'] as $field) {
            if (!isset($data[$field]) || $data[$field] === '' || $data[$field] === []) {
                throw new RuntimeException("Field {$field} wajib diisi.");
            }
        }

        if (!is_array($data['items'])) {
            throw new RuntimeException('Detail pesanan harus berupa array.');
        }

        foreach ($data['items'] as $item) {
            if (
                empty($item['product_id'])
                || !isset($item['quantity'], $item['unit_price'])
                || (float) $item['quantity'] <= 0
                || (float) $item['unit_price'] < 0
                || (float) ($item['discount_amount'] ?? 0) < 0
            ) {
                throw new RuntimeException('Detail produk atau nilai pesanan tidak valid.');
            }
        }
    }

    private function completeTransaction(): void
    {
        if ($this->db->transStatus() === false) {
            throw new RuntimeException('Transaksi database gagal.');
        }

        $this->db->transCommit();
    }
}
