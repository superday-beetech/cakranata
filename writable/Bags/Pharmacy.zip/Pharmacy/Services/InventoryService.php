<?php

declare(strict_types=1);

namespace Modules\Pharmacy\Services;

use Config\Database;
use Modules\Pharmacy\Finance\Models\ProductBatchModel;
use Modules\Pharmacy\Finance\Models\StockMovementModel;
use Modules\Pharmacy\Procurement\Models\GoodsReceiptItemModel;
use Modules\Pharmacy\Procurement\Models\GoodsReceiptModel;
use RuntimeException;
use Throwable;

class InventoryService
{
    protected $db;

    protected GoodsReceiptModel $goodsReceiptModel;
    protected GoodsReceiptItemModel $goodsReceiptItemModel;
    protected ProductBatchModel $productBatchModel;
    protected StockMovementModel $stockMovementModel;

    public function __construct()
    {
        $this->db = Database::connect('pharmacy');

        $this->goodsReceiptModel = new GoodsReceiptModel();
        $this->goodsReceiptItemModel = new GoodsReceiptItemModel();
        $this->productBatchModel = new ProductBatchModel();
        $this->stockMovementModel = new StockMovementModel();
    }

    /**
     * Post Goods Receipt and create product batches.
     *
     * $batchBreakdown format:
     *
     * [
     *     receipt_item_id => [
     *         [
     *             'batch_number' => 'BATCH-001',
     *             'expired_at'   => '2027-12-31',
     *             'quantity'     => 60,
     *         ],
     *     ],
     * ]
     */
    public function postGoodsReceipt(
        int $receiptId,
        array $batchBreakdown,
        int $userId
    ): array {
        $this->db->transBegin();

        try {
            // Lock receipt header.
            $receipt = $this->db->query(
                'SELECT * FROM goods_receipts WHERE id = ? FOR UPDATE',
                [$receiptId]
            )->getRowArray();

            if (!$receipt) {
                throw new RuntimeException(
                    'Goods Receipt tidak ditemukan.'
                );
            }

            if ($receipt['status'] !== 'draft') {
                throw new RuntimeException(
                    'Goods Receipt harus berstatus draft.'
                );
            }

            // Lock receipt details.
            $items = $this->db->query(
                'SELECT * FROM goods_receipt_items
                 WHERE goods_receipt_id = ?
                 FOR UPDATE',
                [$receiptId]
            )->getResultArray();

            if (empty($items)) {
                throw new RuntimeException(
                    'Goods Receipt belum memiliki item.'
                );
            }

            $createdBatches = [];

            foreach ($items as $item) {
                $itemId = (int) $item['id'];

                $batchRows = $batchBreakdown[$itemId] ?? [];

                if (empty($batchRows)) {
                    throw new RuntimeException(
                        "Rincian batch untuk receipt item {$itemId} belum tersedia."
                    );
                }

                $receivedQuantity = (float) $item['quantity_received'];
                $allocatedQuantity = 0;

                foreach ($batchRows as $batch) {
                    $batchNumber = trim(
                        (string) ($batch['batch_number'] ?? '')
                    );

                    $quantity = (float) ($batch['quantity'] ?? 0);

                    $expiredAt = $batch['expired_at'] ?? null;

                    if ($batchNumber === '') {
                        throw new RuntimeException(
                            'Nomor batch wajib diisi.'
                        );
                    }

                    if ($quantity <= 0) {
                        throw new RuntimeException(
                            'Jumlah batch harus lebih besar dari nol.'
                        );
                    }

                    if (
                        $expiredAt !== null &&
                        !$this->isValidDate($expiredAt)
                    ) {
                        throw new RuntimeException(
                            'Format tanggal kedaluwarsa tidak valid.'
                        );
                    }

                    $allocatedQuantity += $quantity;

                    // Create product batch.
                    $batchId = $this->productBatchModel->insert([
                        'product_id'          => $item['product_id'],
                        'goods_receipt_item_id' => $itemId,
                        'batch_number'        => $batchNumber,
                        'expired_at'          => $expiredAt,
                        'received_quantity'   => $quantity,
                        'quantity_remaining'  => $quantity,
                        'unit_cost'           => $item['unit_cost'],
                        'status'              => 'available',
                    ]);

                    if (!$batchId) {
                        throw new RuntimeException(
                            'Gagal membuat product batch.'
                        );
                    }

                    // Record stock ledger.
                    $movementId = $this->stockMovementModel->insert([
                        'product_id'    => $item['product_id'],
                        'batch_id'      => $batchId,
                        'movement_date' => $receipt['received_date'],
                        'movement_type' => 'in',
                        'reference_type' => 'goods_receipt',
                        'reference_id'  => $receiptId,
                        'quantity_in'   => $quantity,
                        'quantity_out'  => 0,
                        'unit_cost'     => $item['unit_cost'],
                        'notes'         => 'Goods Receipt ' . $receipt['receipt_number'],
                        'created_by'    => $userId,
                        'created_at'    => date('Y-m-d H:i:s'),
                    ]);

                    if (!$movementId) {
                        throw new RuntimeException(
                            'Gagal mencatat stock movement.'
                        );
                    }

                    $createdBatches[] = (int) $batchId;
                }

                // Ensure batch quantities match receipt quantity.
                if (
                    abs($allocatedQuantity - $receivedQuantity) > 0.0001
                ) {
                    throw new RuntimeException(
                        "Total batch tidak sama dengan jumlah penerimaan pada item {$itemId}."
                    );
                }
            }

            // Mark receipt as posted.
            if (!$this->goodsReceiptModel->update($receiptId, [
                'status'     => 'posted',
                'updated_by' => $userId,
            ])) {
                throw new RuntimeException(
                    'Gagal memperbarui status Goods Receipt.'
                );
            }

            if ($this->db->transStatus() === false) {
                throw new RuntimeException(
                    'Transaksi inventory gagal.'
                );
            }

            $this->db->transCommit();

            return [
                'receipt_id' => $receiptId,
                'status'     => 'posted',
                'batch_ids'  => $createdBatches,
            ];
        } catch (Throwable $e) {
            $this->db->transRollback();

            throw $e;
        }
    }

    /**
     * Generate FEFO batch allocation.
     *
     * This method only generates an allocation plan.
     * It does not reduce stock.
     */
    public function getFefoAllocation(
        int $productId,
        float $quantity
    ): array {
        if ($quantity <= 0) {
            throw new RuntimeException(
                'Jumlah permintaan harus lebih besar dari nol.'
            );
        }

        $batches = $this->db->query(
            "SELECT
                id,
                batch_number,
                expired_at,
                quantity_remaining,
                unit_cost
             FROM product_batches
             WHERE product_id = ?
               AND status = 'available'
               AND quantity_remaining > 0
               AND (
                    expired_at IS NULL
                    OR expired_at >= CURDATE()
               )
             ORDER BY
                expired_at IS NULL ASC,
                expired_at ASC,
                id ASC",
            [$productId]
        )->getResultArray();

        $remaining = $quantity;
        $allocation = [];

        foreach ($batches as $batch) {
            if ($remaining <= 0) {
                break;
            }

            $available = (float) $batch['quantity_remaining'];

            $allocated = min($available, $remaining);

            $allocation[] = [
                'batch_id'     => (int) $batch['id'],
                'batch_number' => $batch['batch_number'],
                'expired_at'   => $batch['expired_at'],
                'quantity'     => $allocated,
                'unit_cost'    => (float) $batch['unit_cost'],
            ];

            $remaining -= $allocated;
        }

        if ($remaining > 0.0001) {
            throw new RuntimeException(
                'Stok tersedia tidak mencukupi untuk produk ini.'
            );
        }

        return $allocation;
    }

    /**
     * Validate YYYY-MM-DD date.
     */
    private function isValidDate(string $date): bool
    {
        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d', $date);

        return $parsed !== false
            && $parsed->format('Y-m-d') === $date;
    }
}


/**
 * $service = new InventoryService();

$result = $service->postGoodsReceipt(
    1,
    [
        1 => [
            [
                'batch_number' => 'BATCH-001',
                'expired_at'   => '2027-12-31',
                'quantity'     => 60,
            ],
            [
                'batch_number' => 'BATCH-002',
                'expired_at'   => '2028-06-30',
                'quantity'     => 40,
            ],
        ],
        2 => [
            [
                'batch_number' => 'BATCH-003',
                'expired_at'   => '2028-01-31',
                'quantity'     => 50,
            ],
        ],
    ],
    auth()->id()
);
 */
