<?php

declare(strict_types=1);

namespace Modules\Pharmacy\Services;

use Config\Database;
use Modules\Pharmacy\Master\Models\ProductModel;
use Modules\Pharmacy\Master\Models\SupplierModel;
use Modules\Pharmacy\Procurement\Models\PurchaseOrderItemModel;
use Modules\Pharmacy\Procurement\Models\PurchaseOrderModel;
use RuntimeException;
use Throwable;

class ProcurementService
{
    protected $db;

    protected SupplierModel $supplierModel;
    protected ProductModel $productModel;
    protected PurchaseOrderModel $purchaseOrderModel;
    protected PurchaseOrderItemModel $purchaseOrderItemModel;

    public function __construct()
    {
        $this->db = Database::connect('pharmacy');

        $this->supplierModel = new SupplierModel();
        $this->productModel = new ProductModel();

        $this->purchaseOrderModel = new PurchaseOrderModel();
        $this->purchaseOrderItemModel = new PurchaseOrderItemModel();
    }

    /**
     * Create Purchase Order.
     */
    public function createPurchaseOrder(
        array $data,
        int $userId
    ): int {
        $this->validatePurchaseOrder($data);

        $this->db->transBegin();

        try {
            $supplier = $this->supplierModel->find(
                $data['supplier_id']
            );

            if (!$supplier) {
                throw new RuntimeException('Supplier tidak ditemukan.');
            }

            $items = [];
            $subtotal = 0;

            foreach ($data['items'] as $item) {
                $product = $this->productModel->find(
                    $item['product_id']
                );

                if (!$product) {
                    throw new RuntimeException(
                        'Produk ID ' . $item['product_id'] . ' tidak ditemukan.'
                    );
                }

                $quantity = (float) $item['quantity'];
                $unitCost = (float) $item['unit_cost'];
                $discount = (float) ($item['discount_amount'] ?? 0);

                $grossAmount = $quantity * $unitCost;

                if ($discount < 0 || $discount > $grossAmount) {
                    throw new RuntimeException(
                        'Diskon item tidak valid.'
                    );
                }

                $lineSubtotal = $grossAmount - $discount;

                $subtotal += $lineSubtotal;

                $items[] = [
                    'product_id'     => $item['product_id'],
                    'quantity'       => $quantity,
                    'unit_cost'      => $unitCost,
                    'discount_amount' => $discount,
                    'subtotal'       => $lineSubtotal,
                    'notes'          => $item['notes'] ?? null,
                ];
            }

            $discountAmount = (float) (
                $data['discount_amount'] ?? 0
            );

            $taxAmount = (float) (
                $data['tax_amount'] ?? 0
            );

            if (
                $discountAmount < 0 ||
                $discountAmount > $subtotal ||
                $taxAmount < 0
            ) {
                throw new RuntimeException(
                    'Nilai diskon atau pajak tidak valid.'
                );
            }

            $totalAmount = $subtotal
                - $discountAmount
                + $taxAmount;

            $orderId = $this->purchaseOrderModel->insert([
                'order_number'   => $data['order_number'],
                'supplier_id'    => $data['supplier_id'],
                'order_date'     => $data['order_date'],
                'expected_date'  => $data['expected_date'] ?? null,
                'status'         => 'draft',
                'subtotal'       => $subtotal,
                'discount_amount' => $discountAmount,
                'tax_amount'     => $taxAmount,
                'total_amount'   => $totalAmount,
                'notes'          => $data['notes'] ?? null,
                'created_by'     => $userId,
                'updated_by'     => $userId,
            ]);

            if (!$orderId) {
                throw new RuntimeException(
                    'Gagal menyimpan Purchase Order.'
                );
            }

            foreach ($items as $item) {
                $item['purchase_order_id'] = $orderId;

                if (!$this->purchaseOrderItemModel->insert($item)) {
                    throw new RuntimeException(
                        'Gagal menyimpan detail Purchase Order.'
                    );
                }
            }

            if ($this->db->transStatus() === false) {
                throw new RuntimeException(
                    'Transaksi Purchase Order gagal.'
                );
            }

            $this->db->transCommit();

            return (int) $orderId;
        } catch (Throwable $e) {
            $this->db->transRollback();

            throw $e;
        }
    }

    /**
     * Validate Purchase Order payload.
     */
    private function validatePurchaseOrder(array $data): void
    {
        foreach (['order_number', 'supplier_id', 'order_date', 'items'] as $field) {
            if (!isset($data[$field]) || $data[$field] === '') {
                throw new RuntimeException(
                    "Field {$field} wajib diisi."
                );
            }
        }

        if (!is_array($data['items']) || count($data['items']) === 0) {
            throw new RuntimeException(
                'Purchase Order harus memiliki minimal satu item.'
            );
        }

        foreach ($data['items'] as $item) {
            foreach (['product_id', 'quantity', 'unit_cost'] as $field) {
                if (!isset($item[$field]) || !is_numeric($item[$field])) {
                    throw new RuntimeException(
                        "Data item {$field} tidak valid."
                    );
                }
            }

            if (
                (float) $item['quantity'] <= 0 ||
                (float) $item['unit_cost'] < 0
            ) {
                throw new RuntimeException(
                    'Quantity harus positif dan harga tidak boleh negatif.'
                );
            }
        }
    }
}


/**
 *
 * $data = [
    'order_number' => 'PO-2026-0001',
    'supplier_id'  => 1,
    'order_date'   => date('Y-m-d'),
    'expected_date'=> date('Y-m-d', strtotime('+3 days')),

    'discount_amount' => 10000,
    'tax_amount'      => 0,

    'items' => [
        [
            'product_id' => 1,
            'quantity'   => 10,
            'unit_cost'  => 25000,
        ],
        [
            'product_id' => 2,
            'quantity'   => 5,
            'unit_cost'  => 40000,
        ],
    ],
];

$service = new ProcurementService();

$orderId = $service->createPurchaseOrder(
    $data,
    auth()->id()
);
 */
