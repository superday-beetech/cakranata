<?php

declare(strict_types=1);

namespace Modules\Pharmacy\Master\Models;

use Modules\Pharmacy\Models\PharmacyModel;

class CategoryModel extends PharmacyModel
{
    protected $table = 'categories';

    protected $allowedFields = [
        'name',
        'description',
        'is_active',
    ];

    protected $useTimestamps = true;
}
