<?php

declare(strict_types=1);

namespace Modules\Pharmacy\Return\Models;

use Modules\Pharmacy\Models\PharmacyModel;

class SalesReturnItemModel extends PharmacyModel
{
    protected $table = 'sales_return_items';

    protected $allowedFields = [
        'sales_return_id',
        'delivery_item_id',
        'batch_id',
        'quantity',
        'unit_price',
        'subtotal',
        'restockable',
        'condition_notes',
    ];

    protected $useTimestamps = true;
}
