<?php

declare(strict_types=1);

namespace Modules\Pharmacy\Controllers\API\V1;

use App\Core\ApiController;

class PharmacyController extends ApiController
{

    public function __construct() {}

    public function index() {}
}

/*

STANDAR REPONSE DARI ControllerApi
 protected function successResponse(
        $data = null,
        string $message = 'Success',
        int $code = 200
    ) {
        return $this->respond([
            'status'     => $code,
            'error'      => false,
            'message'    => $message,
            'data'       => $data,
            'csrf_token' => $this->getCsrfToken(),
        ], $code);
    }

    protected function errorResponse(
        string|array $message = 'Error',
        int $code = 400,
        $errors = null
    ) {
        $response = [
            'status'     => $code,
            'error'      => true,
            'message'    => $message,
            'csrf_token' => $this->getCsrfToken(),
        ];

        if ($errors !== null) {
            $response['errors'] = $errors;
        }

        return $this->respond($response, $code);
    }

    */
